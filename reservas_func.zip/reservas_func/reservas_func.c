#include <stdio.h>
#include <stdlib.h>
#define aacute  160
#define eacute  130
#define iacute  161
#define oacute  162
#define uacute  163
void mostrar_menu();
void calculaDescuentos();
char tecla =' ';

int main()
{
    do{
        printf("\nPresione una tecla para reservar, Z para salir: ");
        scanf(" %c",&tecla);
        if (tecla !='z' && tecla !='Z'){
                mostrar_menu();

        }
            else break;
    }while(1);

    return 0;
}

void mostrar_menu(){
    printf("\n");
    printf("DNI del titular de la reserva: \n");
    printf("Forma de pago (E:efectivo T:tarjeta de cr%cdito): \n", eacute);
    printf("Cantidad de d%cas que desean hospedarse: \n", iacute);
    printf("Cantidad de personas: \n");

}
